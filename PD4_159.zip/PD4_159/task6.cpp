#include<iostream>
#include<windows.h>
using namespace std;

void gotoxy(int x, int y)
{
COORD coordinates;
coordinates.X = x;
coordinates.Y = y;
SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
}


int main()
{
system("cls");
cout<<"Test";
gotoxy(15, 15);
cout<<"H"<<endl;
gotoxy(15, 16);
cout<<"A"<<endl;
gotoxy(15, 17);
cout<<"S"<<endl;
gotoxy(15, 18);
cout<<"S"<<endl;
gotoxy(15, 19);
cout<<"A"<<endl;
gotoxy(15, 20);
cout<<"N"<<endl;


return 0;
}
