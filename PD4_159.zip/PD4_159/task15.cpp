#include <iostream>
using namespace std;
void flower(float r,float w,float t)
{
float red,white,tulip,dollar;
red=r*2.00;
white=w*4.10;
tulip=t*2.50;
dollar=red+white+tulip;
if(dollar>=200)
{
cout<<"Orignal price: $"<<dollar<<endl;
cout<<"Price after Discount: $"<<dollar-dollar*.2<<endl;
}
else
{
cout<<"Orignal Price: $"<<dollar<<endl;
cout<<"No discount applied."<<endl;
}    
}
main() 
{
int r,w,t;
cout<<"Red Rose: ";
cin>>r;
cout<<"White Rose: ";
cin>>w;
cout<<"Tulips: ";    
cin>>t;
flower(r,w,t);
}