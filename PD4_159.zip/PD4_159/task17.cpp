#include <iostream>
using namespace std;
void tpChecker(int a ,int b){
int c,d,e;
c=500*b;
d=57*a;
e=c/d;
if (e<14)
{
cout<<"Your TP will only last "<<e<<" days, buy more!";
}
else
{
cout<<"Your TP will last "<<e<<" days, no need to panic!";
}
}
main()
{
int a,b;
cout<<"Enter number of the people in the household: ";
cin>>a;
cout<<"Numbers of rolls of TP: ";
cin>>b;
tpChecker(a,b);
}