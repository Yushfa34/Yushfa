#include <iostream>
using namespace std;
void reverse(int a,int b)
{
    if (a==b)
    {
        cout<<"true"<<endl;
    }
    else
    {
        cout<<"false"<<endl;
    }
 }   
  main()
 {
int a,b;
cout<<"Enter the first number: ";
cin>>a;
cout<<"Enter the second number: ";
cin>>b;
reverse(a,b);

}