#include <iostream>
using namespace std;
void tom(float holiday)
{
float a,b,c;
a=365-holiday;
b=a*63+holiday*127;
c=30000-b;
if(c>0)
{
cout<<"Tom sleeps well"<<endl;
cout<<(c)/60<<" hours and "<<(c)/60<<" minutes less for play";
}
else
{
cout<<"Tom will run away"<<endl;
cout<<(-1*c)/60<<" hours and "<<(-1*c)/60<<" minutes for play";
}
}
main() 
{
int holiday;
cout<<"Holidays: ";
cin>>holiday;
tom(holiday);
}