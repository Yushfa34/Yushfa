#include<iostream>
using namespace std;	
string mian()
{
string a;
cout<<"Enter 'true' or 'false': "<<endl;
cin>>a;
}
if (a=="false")
{
 cout<<"true";
}
else if (a=="true")
{
cout<<"false";
}
{
return 0;
}

