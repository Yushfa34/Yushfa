#include<iostream>
using namespace std;
void ticket(string a,float b)
{
    if (a=="Pakistan")
 {
        cout<<"Finnal ticket price after discount: $"<<b-b*0.05;
 }
    else if (a=="Ireland")
{
        cout<<"Finnal ticket price after discount: $"<<b-b*0.1;
    }
    else if (a=="India")
    {
        cout<<"Finnal ticket price after discount: $"<<b-b*0.2;
    }
    else if (a=="England")
    {
        cout<<"Finnal ticket price after discount: $"<<b-b*0.3;
    }
    else if (a=="Canada")
    {
        cout<<"Finnal ticket price after discount: $"<<b-b*0.45;
    }
    
}
int main() {
    string n;
    float a;
    cout<<"Enter the country's name: ";
    cin>>n;
    cout<<"Enter ticket price in dollars: $";
    cin>>a;
    ticket(n,a);

return 0;
}