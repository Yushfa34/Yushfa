#include <iostream>
using namespace std;
void speed(int v)
{
    if(v>=105)
  {
cout<<"Halt... YOU WILL BE CHALLENGED!!!"<<endl;
 }
    else if(v<=100)
  {
cout<<"Perfect! You're going good."<<endl;
 }
    
}
main()
{
int v;
cout<<"Speed: ";
cin>>v;
speed(v);
}