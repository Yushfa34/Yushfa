#include <iostream>
using namespace std;
void duration(float h,float m){
float a=h*60;
if(a>m)
{
cout<<h;
}
else if (a<m)
{
cout<<m;
}
}
main()
{
float h,m;
cout<<"Enter the number of hours: ";
cin>>h;
cout<<"Enter the number of minutes: ";
cin>>m;
duration(h,m);
}